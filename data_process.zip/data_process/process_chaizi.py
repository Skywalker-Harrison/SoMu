'''Load & clean test data from SIGHAN14, SIGHAN15

Author: hengdaxu
 Email: hengdaxu@tencent.com

Cleaning processes:
    1. Make sure no spaces
    2. Traditional Chinese charactor to Simplified
        2.1 OpenCC converter
        2.2 著 -> 着, 妳 -> 你
    3. 「 -> “, 」 -> ”
    4. No English punctuation, only Chinese punctuation
    5. No symbol �
    6. End with Chinese punctuation
'''

import opencc
import argparse
converter = opencc.OpenCC('t2s.json')
from transformers import BertTokenizer

def get_chaizi_dict(chaizi_path='/home/wtl/research/data/chaizi-jt.txt'):
    # 从vocab文件加载BERT Tokenizer
    tokenizer = BertTokenizer.from_pretrained('/home/wtl/research/ReaLiSe/pretrained/vocab.txt')
    unk_id = tokenizer.convert_tokens_to_ids('UNK')
    chaizi_dict = {}
    chaizi_to_char_dict = {}
    with open(chaizi_path,'r',encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            is_in_vocab = True
            elements = line.strip().split('\t')
            char, split = elements[0],elements[-1].replace(' ','')
            for radical in split:
                if tokenizer.convert_tokens_to_ids(radical) == unk_id:
                    is_in_vocab = False
            if is_in_vocab:
                chaizi_dict[char]=split
                if split in chaizi_to_char_dict.keys():
                    chaizi_to_char_dict[split]+=char
                else:
                    chaizi_to_char_dict[split]=char
    return chaizi_dict,chaizi_to_char_dict

def full2half_width(text):

    def char_full2half_width(char):
        code = ord(char)
        if code == 0x3000:
            code = 0x20
        elif 0xff01 <= code <= 0xff5e:
            code -= 0xfee0
        return chr(code)

    res = []
    for c in text:
        if c.isalnum() or c in ['－', '．']:
            c = char_full2half_width(c)
        res.append(c)

    return ''.join(res)


def traditional_to_simple(text):
    text = converter.convert(text)
    text = text.replace('著', '着').replace('妳', '你')
    return text

def is_in_dict(char,chaizi_to_char_dict):
    for key in chaizi_to_char_dict.keys():
        if char in key:
            return True
    return False   

def clean(text):
    text = text.replace('「', '“').replace('」', '”')
    text = text.replace('?', '？').replace(',', '，')
    text = full2half_width(text)
    return text


def find_words(s):
    def is_letter(c):
        return ord('a') <= ord(c.lower()) <= ord('z')
    l = 0
    while True:
        while l < len(s) and not is_letter(s[l]):
            l += 1
        if l == len(s):
            break
        r = l + 1
        while r < len(s) and is_letter(s[r]):
            r += 1
        yield l, r
        l = r

def process_src_tgt_to_equal_len(src,tgt):
    ### 用于拆字问题当中的长度对齐
    output_src=src
    output_tgt=''
    src_pos=0
    for i in range(len(tgt)):
        if src[src_pos] == tgt[i]:
            output_tgt += src[src_pos]
        else:
            output_tgt += '#'
            output_tgt += tgt[i]
            src_pos += 1
        src_pos += 1
    return output_src,output_tgt


def load_test(src_path,tgt_path,chaizi_dict):

    with open(src_path, 'r') as f:
        input_rows = [line.strip().split('\t') for line in f.read().splitlines()]
    with open(tgt_path, 'r') as f:
        label_rows = [line.strip().split(', ') for line in f.read().splitlines()]


    srcs = []
    tgts = []
    with open(src_path,'r',encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            srcs.append(line.strip())

    with open(tgt_path,'r',encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            tgts.append(line.strip())



    data = []
    count = 1
    for src,tgt in zip(srcs, tgts):

        assert src.find(' ') == -1
        src = clean(src)

        item = {}
        data.append(item)

        # Field: id, src
        item['id'] = str(count)
        item['src'] = src
        item['tgt'] = tgt

        if len(item['src']) != len(item['tgt']):
            ### add pad token for unequal length
            src,tgt = process_src_tgt_to_equal_len(item['src'], item['tgt'])
        item['src'] = src
        item['tgt'] = tgt

        # Make sure no English symbols
        for s in r'�．!@$%^&*_+()=`~\|<>,/?:;\'"':
            assert item['src'].find(s) == -1
            assert item['tgt'].find(s) == -1

        # Make sure end with Chinese punctuation
        if not item['src'][-1] in r'。？！：”':
            item['src'] += '。'
            item['tgt'] += '。'

        # Traditional to simple
        item['src'] = traditional_to_simple(item['src'])
        item['tgt'] = traditional_to_simple(item['tgt'])

        # Field: errors
        errors = []
        src = item['src']
        tgt = item['tgt']
        assert len(src)==len(tgt)
        for i in range(len(src)):
            if src[i] != tgt[i]:
                errors.append((i,tgt[i]))
        item['errors']=str(errors)
    return data


            



def write_data(data, output_path):
    rows = ['\t'.join([item['id'], item['src'], item['tgt'],
                       item['errors']]) for item in data]
    with open(output_path, 'w') as f:
        f.write('\n'.join(rows))

    # rows = []
    # for item in data:
    #     row = [item['id']]
    #     if len(eval(item['errors'])) == 0:
    #         row.append('0')
    #     else:
    #         for i, c in eval(item['errors']):
    #             row.append(str(i))
    #             row.append(c)
    #     rows.append(', '.join(row))
    # with open(label_path, 'w') as f:
    #     f.write('\n'.join(rows))


if __name__ == '__main__':
    # data = load_test(
    #     input_path='SIGHAN2015/Test/SIGHAN15_CSC_TestInput.txt',
    #     label_path='SIGHAN2015/Test/SIGHAN15_CSC_TestTruth.txt',
    #     year=15,
    # )

    # data = load_test(
    #     input_path='SIGHAN2013/FinalTest/SIGHAN13_TestInput.txt',
    #     label_path='SIGHAN2013/FinalTest/SIGHAN13_TestTruth.txt',
    #     year=14,
    # )

    parser = argparse.ArgumentParser()
    parser.add_argument('--src_path',type=str,default='/home/jhliang/research/ReaLiSe/data/sighan13/src.txt')
    parser.add_argument('--tgt_path',type=str,default='/home/jhliang/research/ReaLiSe/data/sighan13/tgt.txt')
    parser.add_argument('--output_path',type=str,default='/home/jhliang/research/ReaLiSe/data/sighan13/test.sighan13.tsv')
    args = parser.parse_args()



    chaizi_dict,chaizi_to_char_dict = get_chaizi_dict()

    data = load_test(
        src_path=args.src_path,
        tgt_path=args.tgt_path,
        chaizi_dict=chaizi_dict
    )

    print('#sent:', len(data))
    print('n_sent_err:', sum(len(eval(s['errors'])) > 0 for s in data))
    print('n_err:', sum(len(eval(s['errors'])) for s in data))
    print('Ave len:', sum(len(s['src']) for s in data) / len(data))
    print('max len:', max(len(s['src']) for s in data))
    print('min len:', min(len(s['src']) for s in data))

    # write_data(
    #     data=data,
    #     input_path='data/test.sighan15.tsv',
    #     label_path='data/test.sighan15.lbl.tsv',
    # )

    # write_data(
    #     data=data,
    #     input_path='data/test.sighan14.tsv',
    #     label_path='data/test.sighan14.lbl.tsv',
    # )

    write_data(
        data=data,
        output_path=args.output_path
    )
