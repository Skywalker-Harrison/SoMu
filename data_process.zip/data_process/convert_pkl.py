import pickle
import argparse
def convert_pkl(file_path):
    with open(file_path, 'rb') as f:
        data = pickle.load(f)
    #rewrite-data
    for item in data:
        item['id'] = item['id'][0]
        item['src'] = item['src'][0]
        item['tgt'] = item['tgt'][0]
        item['tokens_size']=item['tokens_size'][0]
        item['src_idx']=item['src_idx'][0].tolist()
        item['tgt_idx']=item['tgt_idx'][0].tolist()
        item['lengths']=item['lengths'][0]
    with open(file_path, 'wb') as f:
        pickle.dump(data, f)

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--pkl_file_path',type=str,required=True)
    args = parser.parse_args()
    convert_pkl(args.pkl_file_path)